import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    allowedHosts: 'all',
    port: 5173,
    open: true,
    hmr: {
      clientPort: 443
    }
  }
})
